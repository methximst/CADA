complete_within_matrix <- function(dat, levels) {
  key <- paste(dat$id, dat$within, sep = "\r")
  duplicated_key <- duplicated(key)

  if (any(duplicated_key)) {
    duplicated_pairs <- unique(key[duplicated_key])
    displayed_pairs <- duplicated_pairs[seq_len(min(5L, length(duplicated_pairs)))]
    stop(
      "Each subject must have at most one value per within level. Duplicate id-within pair(s): ",
      paste(displayed_pairs, collapse = ", "),
      ".",
      call. = FALSE
    )
  }

  subject_ids <- unique(dat$id)
  x_matrix <- matrix(
    NA_real_,
    nrow = length(subject_ids),
    ncol = length(levels),
    dimnames = list(subject_ids, levels)
  )

  row_index <- match(dat$id, subject_ids)
  col_index <- match(dat$within, levels)
  x_matrix[cbind(row_index, col_index)] <- dat$value

  complete_rows <- stats::complete.cases(x_matrix)
  x_matrix <- x_matrix[complete_rows, , drop = FALSE]

  if (nrow(x_matrix) < 2L) {
    stop("At least two complete subjects are required.", call. = FALSE)
  }

  x_matrix
}

covariance_matrix <- function(x_matrix, variance) {
  covariance <- stats::cov(x_matrix)

  if (identical(variance, "population")) {
    covariance <- covariance * (nrow(x_matrix) - 1L) / nrow(x_matrix)
  }

  covariance
}

calculate_within <- function(dv,
                             id,
                             within,
                             h1,
                             h2,
                             data,
                             method,
                             n_boot,
                             seed,
                             deviation,
                             variance,
                             alternative,
                             na.rm) {
  if (is.null(id)) {
    stop("`id` must be supplied when `design = \"within\"`.", call. = FALSE)
  }
  if (is.null(within)) {
    stop("`within` must be supplied when `design = \"within\"`.", call. = FALSE)
  }

  missing_cols <- setdiff(c(id, within, dv), names(data))
  if (length(missing_cols) > 0L) {
    stop(
      "The following column(s) were not found in `data`: ",
      paste(missing_cols, collapse = ", "),
      ".",
      call. = FALSE
    )
  }

  if (!is.numeric(data[[dv]])) {
    stop("The dependent variable `", dv, "` must be numeric.", call. = FALSE)
  }

  dat <- data[c(id, within, dv)]
  names(dat) <- c("id", "within", "value")

  if (na.rm) {
    dat <- dat[stats::complete.cases(dat), , drop = FALSE]
  } else if (anyNA(dat)) {
    stop("Missing values found. Use `na.rm = TRUE` or remove them first.", call. = FALSE)
  }

  if (nrow(dat) == 0L) {
    stop("No complete observations are available for this analysis.", call. = FALSE)
  }

  dat$id <- as.character(dat$id)
  if (is.factor(dat$within)) {
    levels <- base::levels(droplevels(dat$within))
  } else {
    levels <- unique(as.character(dat$within))
  }
  dat$within <- as.character(dat$within)

  if (length(levels) < 2L) {
    stop("At least two within levels are needed.", call. = FALSE)
  }

  h1 <- align_hypothesis(h1, levels, "h1")
  h2 <- align_hypothesis(h2, levels, "h2")

  x_matrix <- complete_within_matrix(dat, levels)
  n_subjects <- nrow(x_matrix)
  n_levels <- ncol(x_matrix)
  means_empirical <- colMeans(x_matrix)
  covariance <- covariance_matrix(x_matrix, variance)
  variance_empirical <- diag(covariance)

  observed <- criterion_from_means(
    means = means_empirical,
    h1 = h1,
    h2 = h2,
    n = rep(n_subjects, n_levels),
    deviation = deviation
  )

  midpoint <- (h1 + h2) / 2
  shift_to_midpoint <- midpoint - means_empirical

  bootstrap <- list()
  if (method %in% c("bootstrap", "both")) {
    shifted_matrix <- sweep(x_matrix, 2L, means_empirical, "-")
    shifted_matrix <- sweep(shifted_matrix, 2L, midpoint, "+")

    if (!is.null(seed)) {
      set.seed(seed)
    }

    dist <- replicate(
      n_boot,
      {
        sampled_rows <- sample.int(n_subjects, size = n_subjects, replace = TRUE)
        means_boot <- colMeans(shifted_matrix[sampled_rows, , drop = FALSE])
        criterion_from_means(
          means = means_boot,
          h1 = h1,
          h2 = h2,
          n = rep(n_subjects, n_levels),
          deviation = deviation
        )$criterion
      }
    )
    dist <- sort(as.numeric(dist))

    bootstrap <- list(
      reverse_bootstrap = FALSE,
      dist = dist,
      var_criterion_boot = stats::var(dist),
      sd_criterion_boot = stats::sd(dist),
      z_boot = z_from_sd(observed$criterion, stats::sd(dist)),
      p_left_boot = mean(dist <= observed$criterion),
      p_right_boot = mean(dist >= observed$criterion),
      p_two_sided_boot = mean(abs(dist) >= abs(observed$criterion))
    )
    bootstrap$p_boot <- p_value_for_alternative(
      p_left = bootstrap$p_left_boot,
      p_right = bootstrap$p_right_boot,
      p_two_sided = bootstrap$p_two_sided_boot,
      alternative = alternative
    )
  }

  normal <- list()
  if (method %in% c("normal", "both")) {
    weights <- 2 * (h2 - h1)
    var_criterion_formula <- n_subjects * as.numeric(t(weights) %*% covariance %*% weights)
    sd_criterion_formula <- sqrt(var_criterion_formula)
    p_values <- normal_p_values(observed$criterion, sd_criterion_formula)

    normal <- list(
      weights = weights,
      var_criterion_formula = var_criterion_formula,
      sd_criterion_formula = sd_criterion_formula,
      z_formula = p_values$z,
      p_left_normal = p_values$p_left,
      p_right_normal = p_values$p_right,
      p_two_sided_normal = p_values$p_two_sided,
      p_normal = p_value_for_alternative(
        p_left = p_values$p_left,
        p_right = p_values$p_right,
        p_two_sided = p_values$p_two_sided,
        alternative = alternative
      )
    )
  }

  z_for_effect <- if (!is.null(normal$z_formula)) normal$z_formula else bootstrap$z_boot
  pooled_within_sd <- sqrt(mean(diag(covariance)))
  fit_rmse_h1 <- sqrt(observed$dev1 / (n_subjects * n_levels))
  fit_rmse_h2 <- sqrt(observed$dev2 / (n_subjects * n_levels))

  within_results <- data.frame(
    level = levels,
    n = rep.int(n_subjects, n_levels),
    mean = unname(means_empirical),
    variance = unname(variance_empirical),
    h1 = unname(h1),
    h2 = unname(h2),
    midpoint = unname(midpoint),
    shift_to_midpoint = unname(shift_to_midpoint),
    dev1 = unname(observed$dev1_by_level),
    dev2 = unname(observed$dev2_by_level),
    criterion_component = unname(observed$dev1_by_level - observed$dev2_by_level),
    weight = unname(if (!is.null(normal$weights)) normal$weights else 2 * (h2 - h1)),
    stringsAsFactors = FALSE
  )

  c(
    list(
      design = "within",
      dv = dv,
      between = NA_character_,
      id = id,
      within = within,
      h1 = h1,
      h2 = h2,
      results_by_level = within_results,
      covariance_matrix = covariance,
      dev1 = observed$dev1,
      dev2 = observed$dev2,
      criterion = observed$criterion,
      n_total = as.integer(n_subjects),
      n_subjects = as.integer(n_subjects),
      n_levels = as.integer(n_levels),
      df_error = as.integer(n_subjects - 1L),
      pooled_within_sd = pooled_within_sd,
      fit_rmse_h1 = fit_rmse_h1,
      fit_rmse_h2 = fit_rmse_h2,
      fit_srmse_h1 = if (pooled_within_sd == 0) NA_real_ else fit_rmse_h1 / pooled_within_sd,
      fit_srmse_h2 = if (pooled_within_sd == 0) NA_real_ else fit_rmse_h2 / pooled_within_sd,
      fit_advantage_h1 = fit_advantage_h1(observed$dev1, observed$dev2),
      criterion_per_subject = observed$criterion / n_subjects,
      r_effectsize = signed_r_from_z(z_for_effect, n_subjects - 1L),
      better_hypothesis = better_hypothesis(observed$criterion)
    ),
    bootstrap,
    normal
  )
}

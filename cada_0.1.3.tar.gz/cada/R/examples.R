simulate_cada_between_data <- function(n_per_group = 40L, seed = 123) {
  n_per_group <- assert_count(n_per_group, "n_per_group")

  if (!is.null(seed)) {
    set.seed(seed)
  }

  groups <- rep(c("Gruppe1", "Gruppe2", "Gruppe3"), each = n_per_group)

  data.frame(
    id = seq_along(groups),
    condition = groups,
    allg = c(
      stats::rnorm(n_per_group, mean = 85, sd = 15),
      stats::rnorm(n_per_group, mean = 100, sd = 15),
      stats::rnorm(n_per_group, mean = 115, sd = 15)
    ),
    verbal = c(
      stats::rnorm(n_per_group, mean = 90, sd = 15),
      stats::rnorm(n_per_group, mean = 100, sd = 15),
      stats::rnorm(n_per_group, mean = 100, sd = 15)
    ),
    math = c(
      stats::rnorm(n_per_group, mean = 110, sd = 15),
      stats::rnorm(n_per_group, mean = 100, sd = 15),
      stats::rnorm(n_per_group, mean = 110, sd = 15)
    ),
    others = c(
      stats::rnorm(n_per_group, mean = 130, sd = 15),
      stats::rnorm(n_per_group, mean = 120, sd = 15),
      stats::rnorm(n_per_group, mean = 115, sd = 15)
    ),
    stringsAsFactors = FALSE
  )
}

make_cada_between_hypotheses <- function(pattern = c(
  "allgh1vsh2",
  "verbalh1vsh2",
  "mathh1vsh2",
  "othersh1vsh2"
)) {
  pattern <- match.arg(pattern)

  switch(
    pattern,
    allgh1vsh2 = list(
      h1 = c(Gruppe1 = 80, Gruppe2 = 95, Gruppe3 = 110),
      h2 = c(Gruppe1 = 90, Gruppe2 = 105, Gruppe3 = 120)
    ),
    verbalh1vsh2 = list(
      h1 = c(Gruppe1 = 90, Gruppe2 = 90, Gruppe3 = 100),
      h2 = c(Gruppe1 = 90, Gruppe2 = 100, Gruppe3 = 110)
    ),
    mathh1vsh2 = list(
      h1 = c(Gruppe1 = 115, Gruppe2 = 100, Gruppe3 = 115),
      h2 = c(Gruppe1 = 90, Gruppe2 = 105, Gruppe3 = 120)
    ),
    othersh1vsh2 = list(
      h1 = c(Gruppe1 = 115, Gruppe2 = 130, Gruppe3 = 115),
      h2 = c(Gruppe1 = 130, Gruppe2 = 120, Gruppe3 = 110)
    )
  )
}

simulate_cada_within_data <- function(n_subjects = 40L,
                                      seed = 123,
                                      levels = c("t1", "t2", "t3"),
                                      means = c(t1 = 92, t2 = 101, t3 = 108),
                                      sd = 15,
                                      correlation = 0.55) {
  n_subjects <- assert_count(n_subjects, "n_subjects")

  if (!is.character(levels) || length(levels) < 2L || anyNA(levels) || any(!nzchar(levels))) {
    stop("`levels` must contain at least two non-missing character values.", call. = FALSE)
  }

  means <- align_hypothesis(means, levels, "means")

  if (!is.numeric(sd) || anyNA(sd) || any(sd <= 0)) {
    stop("`sd` must contain positive numeric value(s).", call. = FALSE)
  }
  if (length(sd) == 1L) {
    sd <- rep(sd, length(levels))
  }
  if (length(sd) != length(levels)) {
    stop("`sd` must have length 1 or length equal to `levels`.", call. = FALSE)
  }

  if (is.matrix(correlation)) {
    if (!all(dim(correlation) == length(levels))) {
      stop("`correlation` matrix must have one row and column per within level.", call. = FALSE)
    }
    corr <- correlation
  } else {
    if (!is.numeric(correlation) || length(correlation) != 1L || is.na(correlation)) {
      stop("`correlation` must be a numeric scalar or a square matrix.", call. = FALSE)
    }
    if (correlation <= -1 || correlation >= 1) {
      stop("Scalar `correlation` must be between -1 and 1.", call. = FALSE)
    }
    corr <- matrix(correlation, nrow = length(levels), ncol = length(levels))
    diag(corr) <- 1
  }

  covariance <- diag(sd, nrow = length(levels)) %*% corr %*% diag(sd, nrow = length(levels))

  if (!is.null(seed)) {
    set.seed(seed)
  }

  z <- matrix(stats::rnorm(n_subjects * length(levels)), nrow = n_subjects)
  values <- z %*% chol(covariance)
  values <- sweep(values, 2L, means, "+")
  colnames(values) <- levels

  data.frame(
    id = rep(seq_len(n_subjects), each = length(levels)),
    time = rep(levels, times = n_subjects),
    score = as.vector(t(values)),
    stringsAsFactors = FALSE
  )
}

make_cada_within_hypotheses <- function(pattern = c(
  "linear_vs_flat",
  "flat_vs_linear",
  "u_vs_linear",
  "decreasing_vs_flat"
)) {
  pattern <- match.arg(pattern)

  switch(
    pattern,
    linear_vs_flat = list(
      h1 = c(t1 = 90, t2 = 100, t3 = 110),
      h2 = c(t1 = 100, t2 = 100, t3 = 100)
    ),
    flat_vs_linear = list(
      h1 = c(t1 = 100, t2 = 100, t3 = 100),
      h2 = c(t1 = 90, t2 = 100, t3 = 110)
    ),
    u_vs_linear = list(
      h1 = c(t1 = 110, t2 = 95, t3 = 110),
      h2 = c(t1 = 90, t2 = 100, t3 = 110)
    ),
    decreasing_vs_flat = list(
      h1 = c(t1 = 110, t2 = 100, t3 = 90),
      h2 = c(t1 = 100, t2 = 100, t3 = 100)
    )
  )
}

#' Compare two hypothesized mean patterns
#'
#' `calc_cada()` is the unified interface for between-subject and within-subject
#' CADA analyses. It compares two hypothesized mean patterns using a quadratic
#' deviation criterion and can compute a bootstrap null distribution, a normal
#' approximation, or both.
#'
#' @param dv Character scalar. Name of the dependent variable.
#' @param h1,h2 Numeric vectors with hypothesized means for hypothesis 1 and 2.
#' @param data A data frame.
#' @param design Either `"between"` or `"within"`.
#' @param method Either `"bootstrap"`, `"normal"`, or `"both"`.
#' @param between Character scalar. Grouping variable for between-subject data.
#' @param id Character scalar. Subject identifier for within-subject data.
#' @param within Character scalar. Within-subject factor for within-subject data.
#' @param n_boot Number of bootstrap samples.
#' @param seed Optional random seed.
#' @param bootstrap_deviation `"squared"` or `"absolute"`. Controls the
#'   bootstrap criterion. `"absolute"` is available for `method = "bootstrap"`;
#'   normal approximations require squared deviations.
#' @param deviation `"squared"` or `"absolute"`. Normal approximations and
#'   combined analyses require `"squared"`. Kept for compatibility; if
#'   `bootstrap_deviation` is not supplied, bootstrap analyses use `deviation`.
#' @param variance `"sample"` uses denominator `n - 1`; `"population"` uses
#'   denominator `n`.
#' @param alternative Direction of the hypothesis comparison. `"h1"` tests
#'   whether hypothesis 1 fits better than hypothesis 2 (`criterion < 0`).
#'   `"h2"` tests whether hypothesis 2 fits better than hypothesis 1
#'   (`criterion > 0`). `"two.sided"` tests whether either hypothesis fits
#'   better than the other, regardless of direction.
#' @param na.rm Logical. If `TRUE`, incomplete rows are removed.
#' @param reverse_bootstrap Optional logical. For between-subject bootstrap with
#'   squared deviations, `NULL` reproduces the earlier `cadaboot` convention and
#'   reverses the bootstrap hypotheses.
#'
#' @return An object of class `"cada"`.
#' @export
calc_cada <- function(dv,
                      h1,
                      h2,
                      data,
                      design = c("between", "within"),
                      method = c("bootstrap", "normal", "both"),
                      between = NULL,
                      id = NULL,
                      within = NULL,
                      n_boot = 1000L,
                      seed = NULL,
                      bootstrap_deviation = c("squared", "absolute"),
                      deviation = c("squared", "absolute"),
                      variance = c("sample", "population"),
                      alternative = c("two.sided", "h1", "h2"),
                      na.rm = TRUE,
                      reverse_bootstrap = NULL) {
  design <- match.arg(design)
  method <- match.arg(method)
  deviation <- match.arg(deviation)
  bootstrap_deviation <- if (missing(bootstrap_deviation)) {
    deviation
  } else {
    match.arg(bootstrap_deviation)
  }
  variance <- match.arg(variance)
  alternative <- normalize_alternative(alternative)

  assert_data_frame(data)
  dv <- assert_string(dv, "dv")
  between <- assert_optional_string(between, "between")
  id <- assert_optional_string(id, "id")
  within <- assert_optional_string(within, "within")
  n_boot <- assert_count(n_boot, "n_boot")

  check_method_deviation(method, deviation, bootstrap_deviation)

  if (!is.null(reverse_bootstrap) &&
      (!is.logical(reverse_bootstrap) || length(reverse_bootstrap) != 1L || is.na(reverse_bootstrap))) {
    stop("`reverse_bootstrap` must be `TRUE`, `FALSE`, or `NULL`.", call. = FALSE)
  }

  if (identical(design, "between")) {
    deviation_for_analysis <- if (identical(method, "bootstrap")) bootstrap_deviation else deviation
    analysis <- calculate_between(
      dv = dv,
      between = between,
      h1 = h1,
      h2 = h2,
      data = data,
      method = method,
      n_boot = n_boot,
      seed = seed,
      deviation = deviation_for_analysis,
      variance = variance,
      alternative = alternative,
      na.rm = na.rm,
      reverse_bootstrap = reverse_bootstrap
    )
  } else {
    deviation_for_analysis <- if (identical(method, "bootstrap")) bootstrap_deviation else deviation
    analysis <- calculate_within(
      dv = dv,
      id = id,
      within = within,
      h1 = h1,
      h2 = h2,
      data = data,
      method = method,
      n_boot = n_boot,
      seed = seed,
      deviation = deviation_for_analysis,
      variance = variance,
      alternative = alternative,
      na.rm = na.rm
    )
  }

  out <- c(
    list(
      call = match.call(),
      method = method,
      deviation = deviation_for_analysis,
      bootstrap_deviation = if (method %in% c("bootstrap", "both")) bootstrap_deviation else NA_character_,
      variance = variance,
      alternative = alternative,
      n_boot = if (method %in% c("bootstrap", "both")) n_boot else NA_integer_,
      seed = seed,
      title = "CADA comparison of competing hypothesized mean patterns"
    ),
    analysis
  )

  class(out) <- "cada"
  out
}

#' Compare two hypotheses for several dependent variables
#'
#' `calc_cada_multi()` applies [calc_cada()] to several dependent variables.
#' `h1` and `h2` can be numeric vectors reused for all dependent variables,
#' named lists, or data frames/matrices whose columns are dependent-variable
#' names and whose row names are groups or within levels.
#'
#' @param dvs Character vector. Dependent variables to analyze.
#' @inheritParams calc_cada
#'
#' @return An object of class `"cada_multi"`.
#' @export
calc_cada_multi <- function(dvs,
                            h1,
                            h2,
                            data,
                            design = c("between", "within"),
                            method = c("bootstrap", "normal", "both"),
                            between = NULL,
                            id = NULL,
                            within = NULL,
                            n_boot = 1000L,
                            seed = NULL,
                            bootstrap_deviation = c("squared", "absolute"),
                            deviation = c("squared", "absolute"),
                            variance = c("sample", "population"),
                            alternative = c("two.sided", "h1", "h2"),
                            na.rm = TRUE,
                            reverse_bootstrap = NULL) {
  design <- match.arg(design)
  method <- match.arg(method)
  deviation <- match.arg(deviation)
  bootstrap_deviation <- if (missing(bootstrap_deviation)) {
    deviation
  } else {
    match.arg(bootstrap_deviation)
  }
  variance <- match.arg(variance)
  alternative <- normalize_alternative(alternative)
  assert_data_frame(data)

  if (!is.character(dvs) || length(dvs) == 0L || anyNA(dvs)) {
    stop("`dvs` must be a non-empty character vector.", call. = FALSE)
  }

  missing_dvs <- setdiff(dvs, names(data))
  if (length(missing_dvs) > 0L) {
    stop(
      "The following dependent variable(s) were not found in `data`: ",
      paste(missing_dvs, collapse = ", "),
      ".",
      call. = FALSE
    )
  }

  seeds <- rep(list(NULL), length(dvs))
  if (!is.null(seed)) {
    set.seed(seed)
    seeds <- as.list(sample.int(.Machine$integer.max, length(dvs)))
  }

  analyses <- lapply(
    seq_along(dvs),
    function(i) {
      dv <- dvs[[i]]
      calc_cada(
        dv = dv,
        h1 = hypothesis_for_dv(h1, dv, "h1"),
        h2 = hypothesis_for_dv(h2, dv, "h2"),
        data = data,
        design = design,
        method = method,
        between = between,
        id = id,
        within = within,
        n_boot = n_boot,
        seed = seeds[[i]],
        bootstrap_deviation = bootstrap_deviation,
        deviation = deviation,
        variance = variance,
        alternative = alternative,
        na.rm = na.rm,
        reverse_bootstrap = reverse_bootstrap
      )
    }
  )
  names(analyses) <- dvs

  results <- do.call(
    rbind,
    lapply(analyses, summary_row)
  )
  row.names(results) <- NULL
  deviation_for_summary <- if (identical(method, "bootstrap")) bootstrap_deviation else deviation

  out <- list(
    call = match.call(),
    title = "CADA comparison for several dependent variables",
    design = design,
    method = method,
    deviation = deviation_for_summary,
    bootstrap_deviation = if (method %in% c("bootstrap", "both")) bootstrap_deviation else NA_character_,
    variance = variance,
    alternative = alternative,
    between = between,
    id = id,
    within = within,
    dvs = dvs,
    n_boot = if (method %in% c("bootstrap", "both")) n_boot else NA_integer_,
    seed = seed,
    results = results,
    analyses = analyses
  )

  class(out) <- "cada_multi"
  out
}

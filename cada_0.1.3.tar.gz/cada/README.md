# cada

`cada` vergleicht zwei inhaltliche Hypothesen über Mittelwerte.

Beispiel: Eine Hypothese erwartet steigende Mittelwerte über drei Gruppen,
eine andere Hypothese erwartet gleiche Mittelwerte. `cada` berechnet, welche
Hypothese näher an den empirischen Daten liegt.

## Installation

```r
install.packages("cada.tar.gz", repos = NULL, type = "source")
library(cada)
```

## Wichtigste Funktion

```r
calc_cada()
```

Die wichtigsten Optionen sind:

- `design = "between"` für unabhängige Gruppen
- `design = "within"` für Messwiederholungen
- `method = "bootstrap"` für die Bootstrap-Variante
- `method = "normal"` für die Normalverteilungsvariante
- `method = "both"` fuer beide Varianten gleichzeitig
- `bootstrap_deviation = "squared"` fuer quadratische Bootstrap-Abweichungen
- `bootstrap_deviation = "absolute"` fuer absolute Bootstrap-Abweichungen
- `alternative = "h1"` fuer einen gerichteten Test zugunsten von Hypothese 1
- `alternative = "h2"` fuer einen gerichteten Test zugunsten von Hypothese 2
- `alternative = "two.sided"` fuer einen ungerichteten Test

## Beispiel: Between-Daten

```r
library(cada)

d <- simulate_cada_between_data(seed = 123)
h <- make_cada_between_hypotheses("allgh1vsh2")

res <- calc_cada(
  dv = "allg",
  between = "condition",
  h1 = h$h1,
  h2 = h$h2,
  data = d,
  design = "between",
  method = "both",
  n_boot = 1000,
  seed = 123,
  alternative = "two.sided"
)

print(res)
summary(res)
plot(res)
```

## Bootstrap mit absoluten Abweichungen

```r
library(cada)

d <- simulate_cada_between_data(seed = 123)
h <- make_cada_between_hypotheses("allgh1vsh2")

res <- calc_cada(
  dv = "allg",
  between = "condition",
  h1 = h$h1,
  h2 = h$h2,
  data = d,
  design = "between",
  method = "bootstrap",
  bootstrap_deviation = "absolute",
  n_boot = 1000,
  seed = 123,
  alternative = "h1"
)

print(res)
summary(res)
plot(res)
```

`bootstrap_deviation = "absolute"` ist für reine Bootstrap-Analysen gedacht.
Die Normalverteilungsvariante im Paket basiert auf quadratischen Abweichungen.

## Beispiel: Within-Daten

```r
library(cada)

d <- simulate_cada_within_data(seed = 123)
h <- make_cada_within_hypotheses("linear_vs_flat")

res <- calc_cada(
  dv = "score",
  id = "id",
  within = "time",
  h1 = h$h1,
  h2 = h$h2,
  data = d,
  design = "within",
  method = "both",
  n_boot = 1000,
  seed = 123,
  alternative = "h1"
)

print(res)
summary(res)
plot(res)
```

## Interpretation

Das wichtigste Ergebnis ist `criterion`.

- `criterion < 0`: Hypothese 1 passt besser.
- `criterion > 0`: Hypothese 2 passt besser.
- `criterion == 0`: Beide Hypothesen passen gleich gut.

In der Ausgabe steht zusätzlich `better_hypothesis`, damit die Richtung direkt
als Text sichtbar ist.

Mit `alternative` legst du fest, welcher p-Wert als zentraler p-Wert berichtet
wird:

- `alternative = "h1"`: gerichteter Test darauf, dass Hypothese 1 besser passt.
  Weil `criterion = D1 - D2` gilt, ist das ein linksseitiger Test.
- `alternative = "h2"`: gerichteter Test darauf, dass Hypothese 2 besser passt.
  Das ist ein rechtsseitiger Test.
- `alternative = "two.sided"`: ungerichteter Test darauf, dass eine der beiden
  Hypothesen besser passt.

Der jeweils ausgewaehlte p-Wert steht in `p_boot` fuer Bootstrap-Ergebnisse und
in `p_normal` fuer die Normalapproximation. In `print()` und `summary()` werden
nur diese zur gewaehlten `alternative` passenden p-Werte angezeigt. Die
vollstaendigen Einzelwerte bleiben im Ergebnisobjekt erhalten, werden aber nicht
automatisch mitgedruckt.
